*TODO: A bit about HMC sampling and HMC Sampling filter...*


======================================================================================================

********************
HMC Sampling Filters
********************

+ `hmc_filter`_
+ `multi_chain_mcmc_filter`_

======================================================================================================



hmc_filter
==========

.. automodule:: dates.src.Assimilation.Assimilation_Schemes.Filters.MCMC.HMC_Sampling_Filters.hmc_filter
    :members:
    :undoc-members:
    :show-inheritance:


multi_chain_mcmc_filter
=======================

.. automodule:: dates.src.Assimilation.Assimilation_Schemes.Filters.MCMC.HMC_Sampling_Filters.multi_chain_mcmc_filter
    :members:
    :undoc-members:
    :show-inheritance:



