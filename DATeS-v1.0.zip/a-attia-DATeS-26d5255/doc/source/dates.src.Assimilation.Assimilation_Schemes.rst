.. We cn add a bit more on the assimilation schemes (filtering/smoothing/hybrid)!

Assimilation_Schemes 
====================

.. toctree::

    Filters <dates.src.Assimilation.Assimilation_Schemes.Filters>
    Smoothers <dates.src.Assimilation.Assimilation_Schemes.Smoothers>



