*TODO: A bit about Sparse Scipy-based Linear Algebra...*


======================================================================================================

********************************************
Sparse Scipy-based Linear_Algebra structures
********************************************

+ `state_matrix_sp_scipy`_
+ `observation_matrix_sp_scipy`_

======================================================================================================


state_matrix_sp_scipy
=====================

.. automodule:: dates.src.Linear_Algebra.Sparse_Scipy.state_matrix_sp_scipy
    :members:
    :undoc-members:
    :show-inheritance:



observation_matrix_sp_scipy
===========================

.. automodule:: dates.src.Linear_Algebra.Sparse_Scipy.observation_matrix_sp_scipy
    :members:
    :undoc-members:
    :show-inheritance:


