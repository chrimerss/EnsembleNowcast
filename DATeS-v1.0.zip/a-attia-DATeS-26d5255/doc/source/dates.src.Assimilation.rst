*TODO: A bit about Assimilation Proceses and Assimilation Schemes...*


======================================================================================================

************
Assimilation
************

.. toctree::
    :maxdepth: 2

    Assimilation Processes <dates.src.Assimilation.Assimilation_Processes>
    Assimilation Schemes <dates.src.Assimilation.Assimilation_Schemes>


======================================================================================================


