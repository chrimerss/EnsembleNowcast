
.. this module has almost no documentation/docstrings :)

****************************
Numpy-based Time Integration
****************************

+ `explicit_runge_kutta`_

+ `linear_implicit_runge_kutta`_


======================================================================================================

    .. _explicit_runge_kutta:

    .. automodule:: dates.src.Time_Integration.Numpy.explicit_runge_kutta
        :members:
        :undoc-members:
        :show-inheritance:



    .. _linear_implicit_runge_kutta:

    .. automodule:: dates.src.Time_Integration.Numpy.linear_implicit_runge_kutta
        :members:
        :undoc-members:
        :show-inheritance:



