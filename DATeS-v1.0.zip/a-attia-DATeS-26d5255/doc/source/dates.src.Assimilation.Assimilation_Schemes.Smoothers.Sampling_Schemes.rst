.. *TODO: A bit about HMC smoothing by sampling...*


======================================================================================================

*********************
Smoothing by Sampling
*********************


.. toctree::

    MCMC Smoothing by Sampling <dates.src.Assimilation.Assimilation_Schemes.Smoothers.Sampling_Schemes.MCMC>


======================================================================================================



