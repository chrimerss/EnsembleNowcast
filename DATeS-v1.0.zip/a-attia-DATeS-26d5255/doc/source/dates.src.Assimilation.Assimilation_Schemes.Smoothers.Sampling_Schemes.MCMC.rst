.. We can add a bit about MCMC in the context of Data Assimilation

MCMC
====

.. toctree::
    
    HMC Smoothing by Sampling <dates.src.Assimilation.Assimilation_Schemes.Smoothers.Sampling_Schemes.MCMC.HMC_Smoothing>



