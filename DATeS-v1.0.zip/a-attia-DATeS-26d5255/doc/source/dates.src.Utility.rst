

*TODO: A bit about the Utility Modules...*


======================================================================================================

*********************
DATeS Utility Modules
*********************

+ `dates_utility`_
+ `_utility_configs`_
+ `_utility_data_assimilation`_
+ `_utility_file_IO`_
+ `_utility_machine_learning`_
+ `_utility_optimization`_
+ `_utility_stat`_
+ `_utility_url`_

======================================================================================================


dates_utility
=============

.. automodule:: dates.src.Utility.dates_utility
    :members:
    :undoc-members:
    :show-inheritance:


_utility_configs          
================

.. automodule:: dates.src.Utility._utility_configs
    :members:
    :undoc-members:
    :show-inheritance:


_utility_data_assimilation
==========================

.. automodule:: dates.src.Utility._utility_data_assimilation
    :members:
    :undoc-members:
    :show-inheritance:

_utility_file_IO          
================

.. automodule:: dates.src.Utility._utility_file_IO
    :members:
    :undoc-members:
    :show-inheritance:

_utility_machine_learning
=========================

.. automodule:: dates.src.Utility._utility_machine_learning
    :members:
    :undoc-members:
    :show-inheritance:

_utility_optimization
=====================

.. automodule:: dates.src.Utility._utility_optimization
    :members:
    :undoc-members:
    :show-inheritance:


_utility_stat
=============

.. automodule:: dates.src.Utility._utility_stat
    :members:
    :undoc-members:
    :show-inheritance:


_utility_url
============

.. automodule:: dates.src.Utility._utility_url
    :members:
    :undoc-members:
    :show-inheritance:




