.. I don't think we need to add more on the Numpy-based error model. Docstrings are enough!


************************
Numpy-based Error Models
************************

+ `error_models_numpy`_

======================================================================================================


error_models_numpy
==================

.. automodule:: dates.src.Error_Models.Numpy.error_models_numpy
    :members:
    :undoc-members:
    :show-inheritance:



