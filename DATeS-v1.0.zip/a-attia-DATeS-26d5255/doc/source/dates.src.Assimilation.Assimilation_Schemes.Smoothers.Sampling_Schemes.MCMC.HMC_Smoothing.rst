*TODO: A bit about HMC smoothing...*


======================================================================================================

*************
HMC_Smoothing
*************

+ `hmc_smoother`_


======================================================================================================


hmc_smoother
============

.. automodule:: dates.src.Assimilation.Assimilation_Schemes.Smoothers.Sampling_Schemes.MCMC.HMC_Smoothing.hmc_smoother
    :members:
    :undoc-members:
    :show-inheritance:


