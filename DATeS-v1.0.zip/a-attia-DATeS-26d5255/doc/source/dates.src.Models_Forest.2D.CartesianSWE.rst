
*************
Cartesian SWE
*************

.. automodule:: dates.src.Models_Forest.2D.CartesianSWE.cartesian_swe_model
    :members:
    :undoc-members:
    :show-inheritance:


======================================================================================================

