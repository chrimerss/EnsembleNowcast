
******************
DATeS Main Modules
******************

.. toctree::

    Linear Algebra <dates.src.Linear_Algebra>
    Models Forest <dates.src.Models_Forest>
    Error Models <dates.src.Error_Models>
    Time Integration <dates.src.Time_Integration>
    Assimilation <dates.src.Assimilation>
    Utility <dates.src.Utility>
    Visualization <dates.src.Visualization>


