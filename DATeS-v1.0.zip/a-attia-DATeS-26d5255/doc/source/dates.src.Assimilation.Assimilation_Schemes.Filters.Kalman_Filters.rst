*TODO: A bit about Kalman Filtering...*


======================================================================================================

**************
Kalman Filters
**************

+ `KF`_
+ `EnKF`_

======================================================================================================



KF
==

.. automodule:: dates.src.Assimilation.Assimilation_Schemes.Filters.Kalman_Filters.KF
    :members:
    :undoc-members:
    :show-inheritance:


EnKF
====

.. automodule:: dates.src.Assimilation.Assimilation_Schemes.Filters.Kalman_Filters.EnKF
    :members:
    :undoc-members:
    :show-inheritance:

