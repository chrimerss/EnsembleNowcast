*TODO: A bit about FATODE package, and the wrapper we developed...*


======================================================================================================

******
FATODE
******

+ `Forward Integrators`_

+ `Adjoint Integrators`_

======================================================================================================


Forward Integrators
===================
*FATODE forward integrators are currently being wrapped*



Adjoint Integrators
===================

.. automodule:: dates.src.Time_Integration.FATODE.fatode_erk_adjoint
    :members:
    :undoc-members:
    :show-inheritance:




