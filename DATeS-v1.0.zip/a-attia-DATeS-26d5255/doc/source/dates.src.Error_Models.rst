*TODO: A bit about Error Models...*


======================================================================================================

************
Error Models
************

+ `Error Models' Base Class`_
+ `Available Error Models`_

======================================================================================================


Error Models' Base Class
========================

.. automodule:: dates.src.Error_Models.error_models_base
    :members:
    :undoc-members:
    :show-inheritance:



Available Error Models
======================

.. toctree::
   :maxdepth: 2

    Numpy-based Error Models <dates.src.Error_Models.Numpy>



