Download
=========


.. raw:: html
    
    Please wait a moment to be re-directed to the download page. </br>
    You can <a href="https://sibiu.cs.vt.edu/dates/Download.html">Click here</a> to get redirected.

    <script>
        window.location.href = "https://sibiu.cs.vt.edu/dates/Download.html";
    </script>
