We will periodically update this list of Tutorials

======================================================================================================

*********
Tutorials
*********

.. toctree::
    :maxdepth: 1

    EnKF applied to Lorenz 96 <Tutorials/lorenz96_enkf/lorenz96_enkf>
    
    DEnKF applied to QG 1.5 <./Tutorials/qg1p5_enkf/qg1p5_enkf>
    
======================================================================================================


