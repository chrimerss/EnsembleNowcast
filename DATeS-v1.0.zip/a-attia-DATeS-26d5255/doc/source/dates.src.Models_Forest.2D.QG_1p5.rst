

*******************************
Quasi Geostrophic Model QG 1.5
*******************************

+ `qg_1p5_model`_

+ `QG 1.5 Erro Models`_

======================================================================================================


qg_1p5_model
============

.. automodule:: dates.src.Models_Forest.2D.QG_1p5.qg_1p5_model
    :members:
    :undoc-members:
    :show-inheritance:



QG 1.5 Erro Models
==================

.. automodule:: dates.src.Models_Forest.2D.QG_1p5.qg_1p5_error_models
    :members:
    :undoc-members:
    :show-inheritance:


