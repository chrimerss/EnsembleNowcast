

**************************
Initialize DATeS for a Run
**************************

**DATeS can easily run without perminant installation:**



dates.dates_setup
=================

.. automodule:: dates.dates_setup
    :members:
    :undoc-members:
    :show-inheritance:


.. code-block:: python
    :caption: In the DATeS root directory run the following statement:
    :name: initilize_dates
         
    import dates_setup
    dates_setup.initialize_dates()
       
           
Run a driver; examples
=======================
.. toctree::
   :maxdepth: 1
   
   See the Tutorials <Tutorials>
    
