Contact
========

If you have questions or requests please contact us at:

+-------------------+---------------------------------+
| `DATeS Team`_     |  dates.assimilation@google.com  |
+-------------------+---------------------------------+
| `Ahmed Attia`_    |  attia@vt.edu                   |
+-------------------+---------------------------------+
| `Adrian Sandu`_   |  sandu@cs.vt.edu                |
+-------------------+---------------------------------+

.. _Ahmed Attia: http://people.cs.vt.edu/~attia/
.. _Adrian Sandu: http://people.cs.vt.edu/~asandu/
.. _DATeS Team: About.html#Contributors

