# initialize the pacage
from dates_setup import *
initialize_dates()


